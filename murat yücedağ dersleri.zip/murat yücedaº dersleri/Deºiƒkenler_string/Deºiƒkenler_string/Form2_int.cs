﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Değişkenler_string
{
    public partial class Form2_int : Form
    {
        public Form2_int()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int sayi;
            //sayi = 24;
            //label1.Text=sayi.ToString();// burada sayi değerini aslında string yapmış olduk
            ////bunun sebebi yazarken hata almamızdır.

            //int sayi1, sayi2,toplam;
            //sayi1 = 4;
            //sayi2 = 5;
            //toplam=sayi1 + sayi2;
            //label1.Text=toplam.ToString();

            int a, b, c, ort;
            a = 90;
            b = 80;
            c = 70;
            ort = (a + b + c) / 3;
            label1.Text = "Sınavların Ortalaması: " + ort;

        }
    }
}
