﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Değişkenler_string
{
    public partial class Form2_odev : Form
    {
        public Form2_odev()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string adı, soyadı, yası, mesleği;
            adı = textBox1.Text;
            soyadı = textBox2.Text;
            yası = maskedTextBox1.Text;
            mesleği = textBox3.Text;

            listBox1.Items.Add( adı + soyadı + yası + mesleği);
        }
    }
}
