﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Değişkenler_string
{
    public partial class Form2_double : Form
    {
        public Form2_double()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //double sayi;
            //sayi = 4.25;
            //label1.Text = sayi.ToString();

            double a, b, c, ort;
            a = 80.8;
            b = 91.3;
            c = 83.2;
            ort = (a + b + c) / 3;
            label1.Text=ort.ToString("0.0");
        }
    }
}
