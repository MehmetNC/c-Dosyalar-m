﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Değişkenler_string
{
    public partial class Form3_int_klavyeden : Form
    {
        public Form3_int_klavyeden()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //int sayi;
            //sayi=Convert.ToInt16(textBox1.Text);
            //label2.Text=sayi.ToString();
            //burda convert etmemizin sebebi textboxa 
            //int bir değer yazamayız o yüzden toint16 ile
            //inte çevirdik artından labele int yazamayacağımız
            //için tekrar stringe çevirdik.

            int sayi,sonuc;
            sayi=Convert.ToInt16(textBox1.Text);
            sonuc = sayi * sayi * sayi;
            label2.Text=sonuc.ToString();
        }
    }
}
