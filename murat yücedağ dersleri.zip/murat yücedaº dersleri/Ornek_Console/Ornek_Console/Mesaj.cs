﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ornek_Console
{
    class Mesaj
    {
        public void metin()
        {
            Console.WriteLine("Merhaba Ankara");
            Console.WriteLine("Merhaba Şanlıurfa");
        }
    }
}
