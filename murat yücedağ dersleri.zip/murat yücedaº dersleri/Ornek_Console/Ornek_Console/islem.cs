﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ornek_Console
{
    class islem
    {
        public int topla(int s1,int s2)
        {
            int s3=s1+s2;
            Console.WriteLine("Sonuç: " + s3);
            return s3;
        }

        public int kare(int x)
        {
            int y = x * x;
            Console.WriteLine("Karesi: "+y);
            return y;
        }

        public int dortislem(int x, int y)
        {
            int z = x * y;
            int a = x + y;
            int b = x - y;
            int c = x / y;
            Console.WriteLine("Çarpma: " + z);
            Console.WriteLine("Toplama: " + a);
            Console.WriteLine("Çıkarma: " + b);
            Console.WriteLine("Bölme: " + c);
            return z;
            return a;
            return b;
            return c;
        }
    }
}
