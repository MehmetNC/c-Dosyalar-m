﻿using System.Reflection.Emit;

namespace Ornek_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            //Mesaj mesaj=new Mesaj();
            //mesaj.metin();


            //Kisiler kisiler = new Kisiler();
            //string ads;
            //Console.Write("isim girin":);
            //ads= Console.ReadLine();
            //kisiler.kisilistesi(ads);


            //islem islem = new islem();
            //islem.topla(7,5);
            //islem.topla(6,5);
            //islem.kare(5);

            //Console.WriteLine();

            //islem.dortislem(4,5);


            //constructor(yapıcılır.)
            //Ogrenci ogrenci = new Ogrenci("sgaggf");

            Kimlik kimlik = new Kimlik();
            kimlik.AD = "Mehmet Nur";
            kimlik.SOYAD = "Ceylan";
            kimlik.MEMLEKET = "Şanlıurfa";
            Console.WriteLine(kimlik.AD);
            Console.WriteLine(kimlik.SOYAD);
            Console.WriteLine(kimlik.MEMLEKET);
            Console.WriteLine(kimlik.YAS);
            Console.WriteLine(kimlik.CINSIYET);
        }
    }
}
