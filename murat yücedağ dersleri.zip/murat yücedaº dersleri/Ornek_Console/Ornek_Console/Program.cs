﻿namespace Ornek_Console
{
    class Program
    {
        static void Main(string[] args)
        {
            Mesaj mesaj = new Mesaj();
            mesaj.metin();
            Console.Read();
        }
    }
}
