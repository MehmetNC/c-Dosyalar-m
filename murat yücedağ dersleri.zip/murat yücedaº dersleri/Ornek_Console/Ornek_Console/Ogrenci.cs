﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ornek_Console
{
    class Ogrenci
    {
        public Ogrenci(string bilgi)
        {
            Console.WriteLine("Ad: Mehmet Nur");
            Console.WriteLine("Soyad: Ceylan");
            Console.WriteLine("Mesleği: Yazılım Mühendisi");

            Console.WriteLine(bilgi);
        }
    }
}
