namespace Diziler
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string[] kisiler = {"Ali", "Ahmet", "Mehmet", "Asl�", "Hakan", "Ay�e", "Demet"};
            //label1.Text = kisiler[4];

            int []sayilar = { 5,4,6,2,7,8,9,1,0,3,6 };
            label1.Text=sayilar[7].ToString();
        }
    }
}
