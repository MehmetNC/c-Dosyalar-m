﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Diziler
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string[] kisiler = { "Ali", "Ahmet", "Mehmet", "Mesut", "Pınar", "Berna" };
            //foreach (string k in kisiler)
            //{
            //    listBox1.Items.Add(k);
            //}

            int[] sayilar = { 2, 4, 1, 5, 6, 7, 2, 3, 4, 3, 4 };
            foreach (int s in sayilar)
            {
                listBox1.Items.Add(s);
            }
        }
    }
}
