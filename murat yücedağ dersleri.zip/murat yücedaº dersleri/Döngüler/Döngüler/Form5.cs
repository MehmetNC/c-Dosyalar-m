﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Döngüler
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        int sayac;
        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
        
        private void timer1_Tick(object sender, EventArgs e)
        {
            //sayac++;
            //label1.Text = sayac.ToString();
            //if (sayac==2)
            //{
            //    this.BackColor = Color.Red;
            //}
            //if (sayac == 4)
            //{
            //    this.BackColor=Color.Blue;
            //    sayac = 0;
            //}

            sayac++;
            label1.Text = sayac.ToString();
            if (sayac <= 30)
            {
                this.BackColor = Color.Red;
            }
            
            else if (sayac >= 31 && sayac <= 40)
            {
                this.BackColor = Color.Yellow;
            }
            
            else if (sayac >= 41 && sayac <= 70)
            {
                this.BackColor = Color.Green;
            }
            else if (sayac >=70)
            {
                sayac = 0;
            }
        }
    }
}
