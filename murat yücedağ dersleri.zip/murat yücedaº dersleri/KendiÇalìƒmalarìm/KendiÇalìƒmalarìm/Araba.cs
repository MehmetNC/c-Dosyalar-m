﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KendiÇalışmalarım
{
    public class Araba
    {
        public int kapiSayisi;
        public string arabaModeli;
        public string arabaRengi;

        public Araba(int _kapiSayisi,string _arabaModeli,string _arabaRengi)//Constructor
        {
            kapiSayisi = _kapiSayisi;
            arabaModeli = _arabaModeli;
            arabaRengi = _arabaRengi;
        }

        public void motorCalistir()
        {
            Console.WriteLine("Motor Çalışıyor");
        }
        public void kapilariKilitle()
        {
            Console.WriteLine("Kapılar Kilitlendi");
        }
    }
}
