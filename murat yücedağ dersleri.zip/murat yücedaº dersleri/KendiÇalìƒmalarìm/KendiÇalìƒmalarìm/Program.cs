﻿using KendiÇalışmalarım;

namespace ClassKullanımı
{
    class program
    {
        static void Main(String[] args)
        {
            Araba araba = new Araba(4,"Mercedes","Kırmızı");

            araba.motorCalistir();
            araba.kapilariKilitle();

            Console.WriteLine("Arabanın kapı sayısı: " + araba.kapiSayisi);
            Console.WriteLine("Arabanın rengi: " + araba.arabaRengi);
            Console.WriteLine("Arabanın modeli: " + araba.arabaModeli);
        }
    }
}
