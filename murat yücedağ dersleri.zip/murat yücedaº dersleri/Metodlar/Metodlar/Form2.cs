﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodlar
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        int toplam(int s1, int s2,int s3)
        {
            int s4=s1*s2*s3;
            return s4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = toplam(4, 6, 5).ToString();
            label2.Text = toplam(7, 4, 4).ToString();
            label3.Text = toplam(6, 8, 9).ToString();
        }
    }
}
