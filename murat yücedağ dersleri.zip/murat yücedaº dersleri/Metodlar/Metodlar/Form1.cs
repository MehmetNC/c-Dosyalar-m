namespace Metodlar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void temizle()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox1.Focus();
        }

        void renklendir()//voidin �n�ne bi�ey yaz�lmazsa private demektir.
        {
            textBox1.BackColor = Color.Red;
            textBox2.BackColor = Color.Green;
            textBox3.BackColor = Color.Yellow;
            textBox4.BackColor = Color.Gray;
        }

        void bilgiler()
        {
            textBox1.Text = "Mehmet Nur";
            textBox2.Text = "Ceylan";
            textBox3.Text = "Yaz�l�m M�hendisi";
            textBox4.Text = "�anl�urfa";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            temizle();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            renklendir();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bilgiler();
        }
    }
}
