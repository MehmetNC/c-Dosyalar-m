namespace Araç_Kullanimi_Odev
{
    public partial class Arac_Kullanim_odevi : Form
    {
        public Arac_Kullanim_odevi()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = textBox1.Text;
            label5.Text = textBox2.Text;
            label6.Text = textBox3.Text;
        }
    }
}
