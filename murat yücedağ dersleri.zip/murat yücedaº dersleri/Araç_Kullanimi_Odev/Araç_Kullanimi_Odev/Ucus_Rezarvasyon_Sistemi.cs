﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Araç_Kullanimi
{
    public partial class Ucus_Rezarvasyon_Sistemi : Form
    {
        public Ucus_Rezarvasyon_Sistemi()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Add("Rota:" + comboBox1.Text + "-" + comboBox2.Text + " Tarih:" + dateTimePicker1.Text + " Saat:" + maskedTextBox1.Text + "Yolcu Bilgiler i~ Adı Soyadı:" + textBox1.Text + " Yolcunun T.C.:" + maskedTextBox2.Text + " Yolcunun Telefon Numarası:" + maskedTextBox3.Text);
            MessageBox.Show("Yolcu Kaydı Yapıldı...");
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label9.Text= comboBox2.Text;
            comboBox2.Text=comboBox1.Text;
            comboBox1.Text=label9.Text;
        }
    }
}
