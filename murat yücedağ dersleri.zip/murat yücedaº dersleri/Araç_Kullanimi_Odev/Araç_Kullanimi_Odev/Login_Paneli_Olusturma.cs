﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Araç_Kullanimi
{
    public partial class Login_Paneli_Olusturma : Form
    {
        public Login_Paneli_Olusturma()
        {
            InitializeComponent();
        }
    }
}
