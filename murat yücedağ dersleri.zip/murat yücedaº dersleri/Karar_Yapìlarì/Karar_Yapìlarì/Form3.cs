﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Karar_Yapıları
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int adet;
            double toplam;
            adet=Convert.ToInt16(textBox1.Text);
            if (adet>=0 && adet<=20)
            {
                toplam = (adet * 8) * 0.8;
                label3.Text = toplam + "TL";
            }
            if (adet>=21 && adet<=40)
            {
                toplam = (adet * 8) * 0.6;
                label3.Text = toplam + "TL";
            }
            if (adet >=41)
            {
                toplam = (adet * 8) * 0.5;
                label3.Text = toplam + "TL";
            }
        }
    }
}
