namespace Karar_Yapıları
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (textBox1.Text=="Ali")
            //{
            //    label1.Text = "Doğru";
            //}
            //else
            //{
            //    label1.Text = "Yanlış";
            //}

            //int a = Convert.ToInt16(textBox1.Text);
            //if (a==5)
            //{
            //    label1.Text = "Doğru";
            //}
            //else
            //{
            //    label1.Text = "Yanlış";
            //}

            //int a = Convert.ToInt16(textBox1.Text);
            //if (a % 2 ==0 && a>=10)
            //{
            //    label1.Text = "Çift ve 10'dan büyük";
            //}
            //else
            //{
            //    label1.Text = "Tek veya 10'dan büyük küçük olabilir.";
            //}

            int a = Convert.ToInt16(textBox1.Text);
            if (a % 2 == 0 || a >= 10)
            {
                label1.Text = "Çift ve 10'dan büyük";
            }
            else
            {
                label1.Text = "Tek veya 10'dan büyük küçük olabilir.";
            }
        }
    }
}
