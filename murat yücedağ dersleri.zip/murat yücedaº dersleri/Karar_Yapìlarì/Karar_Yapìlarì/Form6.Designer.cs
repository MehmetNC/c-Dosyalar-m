﻿namespace Karar_Yapıları
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            richTextBox1 = new RichTextBox();
            BtnA = new Button();
            BtnD = new Button();
            BtnC = new Button();
            BtnB = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            LblSoruno = new Label();
            LblDogru = new Label();
            LblYanlıs = new Label();
            BtnSonraki = new Button();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label4 = new Label();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // richTextBox1
            // 
            richTextBox1.Location = new Point(-1, 0);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(333, 140);
            richTextBox1.TabIndex = 0;
            richTextBox1.Text = "";
            // 
            // BtnA
            // 
            BtnA.BackColor = SystemColors.AppWorkspace;
            BtnA.Location = new Point(-1, 146);
            BtnA.Name = "BtnA";
            BtnA.Size = new Size(160, 39);
            BtnA.TabIndex = 1;
            BtnA.Text = "A";
            BtnA.UseVisualStyleBackColor = false;
            BtnA.Click += BtnA_Click;
            // 
            // BtnD
            // 
            BtnD.BackColor = SystemColors.AppWorkspace;
            BtnD.Location = new Point(165, 191);
            BtnD.Name = "BtnD";
            BtnD.Size = new Size(160, 39);
            BtnD.TabIndex = 2;
            BtnD.Text = "D";
            BtnD.UseVisualStyleBackColor = false;
            BtnD.Click += BtnD_Click;
            // 
            // BtnC
            // 
            BtnC.BackColor = SystemColors.AppWorkspace;
            BtnC.Location = new Point(-1, 191);
            BtnC.Name = "BtnC";
            BtnC.Size = new Size(160, 39);
            BtnC.TabIndex = 3;
            BtnC.Text = "C";
            BtnC.UseVisualStyleBackColor = false;
            BtnC.Click += BtnC_Click;
            // 
            // BtnB
            // 
            BtnB.BackColor = SystemColors.AppWorkspace;
            BtnB.Location = new Point(165, 146);
            BtnB.Name = "BtnB";
            BtnB.Size = new Size(160, 39);
            BtnB.TabIndex = 4;
            BtnB.Text = "B";
            BtnB.UseVisualStyleBackColor = false;
            BtnB.Click += BtnB_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(342, 20);
            label1.Name = "label1";
            label1.Size = new Size(71, 19);
            label1.TabIndex = 5;
            label1.Text = "Soru No:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(357, 55);
            label2.Name = "label2";
            label2.Size = new Size(58, 19);
            label2.TabIndex = 6;
            label2.Text = "Doğru:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(358, 87);
            label3.Name = "label3";
            label3.Size = new Size(55, 19);
            label3.TabIndex = 7;
            label3.Text = "Yanlış:";
            // 
            // LblSoruno
            // 
            LblSoruno.AutoSize = true;
            LblSoruno.Location = new Point(419, 20);
            LblSoruno.Name = "LblSoruno";
            LblSoruno.Size = new Size(17, 19);
            LblSoruno.TabIndex = 8;
            LblSoruno.Text = "0";
            // 
            // LblDogru
            // 
            LblDogru.AutoSize = true;
            LblDogru.Location = new Point(419, 55);
            LblDogru.Name = "LblDogru";
            LblDogru.Size = new Size(17, 19);
            LblDogru.TabIndex = 9;
            LblDogru.Text = "0";
            // 
            // LblYanlıs
            // 
            LblYanlıs.AutoSize = true;
            LblYanlıs.Location = new Point(419, 87);
            LblYanlıs.Name = "LblYanlıs";
            LblYanlıs.Size = new Size(17, 19);
            LblYanlıs.TabIndex = 10;
            LblYanlıs.Text = "0";
            // 
            // BtnSonraki
            // 
            BtnSonraki.BackColor = SystemColors.AppWorkspace;
            BtnSonraki.Location = new Point(357, 118);
            BtnSonraki.Name = "BtnSonraki";
            BtnSonraki.Size = new Size(122, 32);
            BtnSonraki.TabIndex = 11;
            BtnSonraki.Text = "Sonraki";
            BtnSonraki.UseVisualStyleBackColor = false;
            BtnSonraki.Click += BtnSonraki_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(340, 156);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(73, 80);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 12;
            pictureBox1.TabStop = false;
            pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(419, 156);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(73, 80);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 13;
            pictureBox2.TabStop = false;
            pictureBox2.Visible = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(229, 264);
            label4.Name = "label4";
            label4.Size = new Size(50, 19);
            label4.TabIndex = 14;
            label4.Text = "label4";
            label4.Visible = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(229, 310);
            label5.Name = "label5";
            label5.Size = new Size(50, 19);
            label5.TabIndex = 15;
            label5.Text = "label5";
            label5.Visible = false;
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(9F, 19F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(503, 260);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(BtnSonraki);
            Controls.Add(LblYanlıs);
            Controls.Add(LblDogru);
            Controls.Add(LblSoruno);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(BtnB);
            Controls.Add(BtnC);
            Controls.Add(BtnD);
            Controls.Add(BtnA);
            Controls.Add(richTextBox1);
            Font = new Font("Corbel", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Margin = new Padding(4);
            Name = "Form6";
            Text = "Form6";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private RichTextBox richTextBox1;
        private Button BtnA;
        private Button BtnD;
        private Button BtnC;
        private Button BtnB;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label LblSoruno;
        private Label LblDogru;
        private Label LblYanlıs;
        private Button BtnSonraki;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label4;
        private Label label5;
    }
}