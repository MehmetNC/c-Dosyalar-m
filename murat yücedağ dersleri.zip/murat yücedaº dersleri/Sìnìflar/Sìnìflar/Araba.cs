﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sınıflar
{
    class Araba:ArabaDetay1//kalıtım yapıldıktan sonra
        //label8,9,10 için doğrudan işlem yapılır hale gelir
    {
        public string renk;
        public int hiz;
        public double motor;
        public char durum;
        public int fiyat;
        private int yil;
        private string marka;

        //private olan yerler için get ve set kullanılarak 
        //nesnelerde okunması sağlanır.
        public int YIL
        { 
            get {return yil;}
            set {yil = Math.Abs(value);}
        }
        public string MARKA
        {
            get { return marka; }
            set { marka = value.ToUpper(); }
        }
    }
}
