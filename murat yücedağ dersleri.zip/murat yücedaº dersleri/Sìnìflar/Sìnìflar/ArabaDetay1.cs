﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sınıflar
{
    class ArabaDetay1
    {
        public string plaka;
        public int muayene;
        public string sahip;
    }
}
