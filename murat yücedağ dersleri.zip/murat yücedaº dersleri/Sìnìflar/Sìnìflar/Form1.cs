namespace Sınıflar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Araba araba = new Araba();
            araba.renk = "mavi";
            araba.hiz = 160;
            araba.motor = 1245.56;
            araba.fiyat = 50000;
            araba.durum = 's';
            //label 6 ve 7 kısımları kapsülleme için
            araba.YIL = -2016;
            araba.MARKA = "golf";
            araba.muayene = 2017;
            araba.plaka = "34 MK 1881";
            araba.sahip = "Mehmet Nur Ceylan";

            label1.Text= araba.renk;
            label2.Text=araba.hiz.ToString();
            label3.Text= araba.motor.ToString();
            label4.Text= araba.fiyat.ToString();
            label5.Text= araba.durum.ToString();
            label6.Text= araba.YIL.ToString();
            label7.Text= araba.MARKA;
            label8.Text= araba.muayene.ToString();
            label9.Text= araba.plaka;
            label10.Text= araba.sahip.ToString();
        }
    }
}
